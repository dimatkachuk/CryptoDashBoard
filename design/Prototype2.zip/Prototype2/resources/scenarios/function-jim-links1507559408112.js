(function(window, undefined) {

  var jimLinks = {
    "91b3d0f1-7e21-494e-b59e-bb38dd3b24f9" : {
      "Image_1" : [
        "fdff255f-c8f7-4a5e-a7c0-ad8f1a92b9c0"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Image_2" : [
        "2ac94d87-67d0-42dd-ad7e-b8f6d46683b7"
      ]
    },
    "fdff255f-c8f7-4a5e-a7c0-ad8f1a92b9c0" : {
      "Image_4" : [
        "91b3d0f1-7e21-494e-b59e-bb38dd3b24f9"
      ]
    },
    "2ac94d87-67d0-42dd-ad7e-b8f6d46683b7" : {
      "Button_2" : [
        "fdff255f-c8f7-4a5e-a7c0-ad8f1a92b9c0"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);