(function(window, undefined) {

    /*********************** START STATIC ACCESS METHODS ************************/

    jQuery.extend(jimMobile, {
        "loadScrollBars": function() {
            jQuery(".s-91b3d0f1-7e21-494e-b59e-bb38dd3b24f9 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-fdff255f-c8f7-4a5e-a7c0-ad8f1a92b9c0 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-2ac94d87-67d0-42dd-ad7e-b8f6d46683b7 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
         }
    });

    /*********************** END STATIC ACCESS METHODS ************************/

}) (window);