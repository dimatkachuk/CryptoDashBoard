(function(window, undefined) {

    /*********************** START STATIC ACCESS METHODS ************************/

    jQuery.extend(jimMobile, {
        "loadScrollBars": function() {
            jQuery(".s-f0faf42f-0ddc-435b-99e2-3e9cc79e78d2 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-5aa7a7f8-5e3b-4124-8a52-ebf9512a6b37 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-ed358f54-e528-491a-aec9-a06eedc1a9c7 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
         }
    });

    /*********************** END STATIC ACCESS METHODS ************************/

}) (window);