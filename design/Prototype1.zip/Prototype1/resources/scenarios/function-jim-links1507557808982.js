(function(window, undefined) {

  var jimLinks = {
    "f0faf42f-0ddc-435b-99e2-3e9cc79e78d2" : {
      "Image_150" : [
        "5aa7a7f8-5e3b-4124-8a52-ebf9512a6b37"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Image_1" : [
        "ed358f54-e528-491a-aec9-a06eedc1a9c7"
      ]
    },
    "5aa7a7f8-5e3b-4124-8a52-ebf9512a6b37" : {
      "Image_21" : [
        "f0faf42f-0ddc-435b-99e2-3e9cc79e78d2"
      ]
    },
    "ed358f54-e528-491a-aec9-a06eedc1a9c7" : {
      "Button_1" : [
        "5aa7a7f8-5e3b-4124-8a52-ebf9512a6b37"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);